package br.ufsm.lpbd.banking.core;
/*
 * @author Cristiano de Favari
 * Universidade Federal de Santa Maria
 * 
 */ 
public interface SavingsAccount extends Account {

}
